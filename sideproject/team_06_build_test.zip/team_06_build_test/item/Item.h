#ifndef SIDESCROLLER_ITEM_H
#define SIDESCROLLER_ITEM_H


class Item {

};


#endif //SIDESCROLLER_ITEM_H
