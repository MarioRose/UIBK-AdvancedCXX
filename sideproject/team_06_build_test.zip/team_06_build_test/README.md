Compile with:
	cmake -GNinja
	ninja

Start executable then with ./app/sidescroller
