//
// Created by christoph on 27.11.18.
//

#ifndef SIDESCROLLER_GAMEOBJECTMANAGER_H
#define SIDESCROLLER_GAMEOBJECTMANAGER_H


class GameObjectManager {

};


#endif //SIDESCROLLER_GAMEOBJECTMANAGER_H
